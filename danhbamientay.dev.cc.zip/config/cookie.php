<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cookies that should not be encrypted
    |--------------------------------------------------------------------------
    |
    | OctoberCMS encrypts/decrypts cookies by default. You can specify cookies
    | that should not be encrypted or decrypted here. This is useful, for
    | example, when you want to pass data from frontend to server side backend
    | via cookies, and vice versa.
    |
    */

    'unencryptedCookies' => [
        // 'my_cookie',
    ],

];
